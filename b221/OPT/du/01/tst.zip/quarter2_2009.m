function M = quarter2_2009(x)
%QUARTER2_2009 Summary of this function goes here
%   Detailed explanation goes here
M = x(1) + x(2)*2009.25;
end

