function [x_, y_] = translation(x, y, tx, ty)
    % function [x_, y_ ] = translation(x, y, tx, ty)
    %     x_ = x + tx;
    %     y_ = y + ty;

    x_ = x + tx;
    y_ = y + ty;
end
