#include <iostream>
#include <vector>
#include <set>
#include <tuple>
#include <cmath>
#include <algorithm>
#include <numeric>

using namespace std;

int input(long long int numbers[], int N);

int findPrimes(set<int> &primes, int Pmax);

set<long long int> generateCandidateMods(const set<int> &primes, long long int Mmax);

long long int findMod(long long int numbers[], int N);

long long int findMultiplier(long long int numbers[], long long int M);

long long int findIncrement(long long int numbers[], long long int M, long long int A);

bool verify(long long int numbers[], long long int M, long long int A, long long int C, int N);

tuple<long long int, long long int, long long int> egcd(long long int a, long long int b);

long long int modInverse(long long int a, long long int m);

int main() {
    int Pmax, N;
    long long int Mmax;

    // Read inputs
    if (scanf("%i %lli %i", &Pmax, &Mmax, &N) != 3) return EXIT_FAILURE;

    if (Pmax < 5 || Pmax > 503) return EXIT_FAILURE;
    if (Mmax < 25 || Mmax > 2 * pow(10, 18)) return EXIT_FAILURE;
    if (N < 10 || N > 30) return EXIT_FAILURE;

    long long int numbers[N];
    if (input(numbers, N) != EXIT_SUCCESS) return EXIT_FAILURE;

    // Generate primes
    set<int> primes;
    findPrimes(primes, Pmax);

    // Generate candidate modulus values
    set<long long int> candidateMods = generateCandidateMods(primes, Mmax);

    // Search for valid (A, C, M)
    for (long long int M: candidateMods) {
        long long int A = findMultiplier(numbers, M);
        if (A == -1) continue; // Skip if multiplier cannot be calculated

        long long int C = findIncrement(numbers, M, A);
        if (C == -1) continue; // Skip if increment cannot be calculated

        if (verify(numbers, M, A, C, N)) {
            printf("%lli %lli %lli\n", A, C, M);
            return EXIT_SUCCESS;
        }
    }

    return EXIT_FAILURE; // No valid LCG parameters found
}

int input(long long int numbers[], int N) {
    for (int i = 0; i < N; i++) {
        if (scanf("%lli", &numbers[i]) != 1) return EXIT_FAILURE;
    }
    return EXIT_SUCCESS;
}

// Generate primes up to Pmax
int findPrimes(set<int> &primes, int Pmax) {
    vector<bool> isPrime(Pmax + 1, true);
    isPrime[0] = isPrime[1] = false;

    for (int i = 2; i * i <= Pmax; i++) {
        if (isPrime[i]) {
            for (int j = i * i; j <= Pmax; j += i) {
                isPrime[j] = false;
            }
        }
    }

    for (int i = 5; i <= Pmax; i++) {
        if (isPrime[i]) {
            primes.insert(i);
        }
    }
    return EXIT_SUCCESS;
}

// Generate candidate modulus values
set<long long int> generateCandidateMods(const set<int> &primes, long long int Mmax) {
    set<long long int> mods;
    vector<long long int> products = {1};

    for (int prime: primes) {
        vector<long long int> newProducts;
        for (long long int product: products) {
            long long int newMod = product * prime * prime;
            if (newMod > Mmax) continue;
            newProducts.push_back(newMod);
            mods.insert(newMod);
        }
        products.insert(products.end(), newProducts.begin(), newProducts.end());
    }
    return mods;
}

// Find modulus M based on sequence differences
long long int findMod(long long int numbers[], int N) {
    vector<long long int> diffs(N - 1);
    for (int i = 0; i < N - 1; i++) {
        diffs[i] = numbers[i + 1] - numbers[i];
    }

    vector<long long int> zeros(N - 2);
    for (int i = 0; i < N - 2; i++) {
        zeros[i] = diffs[i + 1] * diffs[i + 1] - diffs[i] * diffs[i + 2];
    }

    long long int gcdAll = abs(zeros[0]);
    for (int i = 1; i < zeros.size(); i++) {
        gcdAll = __gcd(gcdAll, abs(zeros[i]));
    }

    return gcdAll;
}

// Find multiplier A
long long int findMultiplier(long long int numbers[], long long int M) {
    long long int diff1 = (numbers[1] - numbers[0] + M) % M;
    long long int diff2 = (numbers[2] - numbers[1] + M) % M;

    long long int inv = modInverse(diff1, M);
    if (inv == -1) return -1; // Modular inverse does not exist

    return (diff2 * inv) % M;
}

// Find increment C
long long int findIncrement(long long int numbers[], long long int M, long long int A) {
    long long int C = (numbers[1] - A * numbers[0]) % M;
    if (C < 0) C += M;
    return C;
}

// Verify the sequence
bool verify(long long int numbers[], long long int M, long long int A, long long int C, int N) {
    for (int i = 1; i < N; i++) {
        long long int expected = (A * numbers[i - 1] + C) % M;
        if (expected != numbers[i]) return false;
    }
    return true;
}

// Extended GCD for modular inverse
tuple<long long int, long long int, long long int> egcd(long long int a, long long int b) {
    if (a == 0) return {b, 0, 1};
    auto [g, x, y] = egcd(b % a, a);
    return {g, y - (b / a) * x, x};
}

// Modular inverse using Extended GCD
long long int modInverse(long long int a, long long int m) {
    auto [g, x, _] = egcd(a, m);
    if (g != 1) return -1; // Inverse does not exist
    return (x % m + m) % m;
}
